alias d='docker $*'
alias d-c='docker-compose $*'
