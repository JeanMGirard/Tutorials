#!/bin/bash
set -x

# runs on sunday and thursday at midnight

PATH=~/.homebrew/bin:~/.homebrew/sbin:/~/code/depot_tools:$PATH

